$netid = Read-Host("Entrez votre NetID, exemple: si votre adresse IP est 192.168.1.100 et que votre masque est /24, votre NetID va �tre '192.168.1.0/24' | Si votre masque �tait /8, votre NetID va �tre '192.0.0.0/8' ...etc")

Add-DnsServerPrimaryZone -NetworkId $netid -ReplicationScope 'Domain'

schtasks /delete /tn "3dns" /f

 #Restart-Computer -Force

