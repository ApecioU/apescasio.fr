# 
# Script pour changer le nom de PC + configurer l'IP, mettre IP + masque + passerelle... en statique (IP est dynamique normalement par d�faut)
#

$nom = Read-Host("Entrez le nouveau nom de PC portable")

Rename-Computer $nom

$index = Read-Host("Entrez le num�ro index de la carte r�seau Ethernet, c'est 5 normalement, vous pouvez voir avec la commande Get-NetAdapter")

$ip = Read-Host("Entrez l'adresse IP, exemple: 192.168.1.100")

$mask = Read-Host("Entrez le masque en notation CIDR mais sans le slash, exemple: 8, 8 signifie 255.0.0.0")

$gw = Read-Host("Entrez l'adresse IP de la passerelle, exemple: 192.168.1.254")

New-NetIPAddress -InterfaceIndex $index -IPAddress $ip -PrefixLength $mask -DefaultGateway $gw

Set-DnsClientServerAddress -InterfaceIndex $index -ServerAddresses $ip

schtasks /create /tn "2adds" /tr "powershell.exe -ExecutionPolicy Bypass -File C:%HOMEPATH%\Downloads\dcc\2adds.ps1" /rl highest /sc onlogon

Restart-Computer -Force
