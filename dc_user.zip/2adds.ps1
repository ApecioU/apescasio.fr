#
# Script pour cr�er un AD DS
#

$pw = Read-Host("Entrez le mot de passe, 12 caract�res minimum..")
$domain_name = Read-Host("Entrez le nom de domaine complet, exemple: apescasio.loc")
$domain_netbios = Read-Host("Entrez le nom de domaine NET-BIOS, exemple: APES")

Install-WindowsFeature -name AD-Domain-Services �IncludeManagementTools
Install-ADDSForest `
-CreateDnsDelegation:$false `
-SafeModeAdministratorPassword:(ConvertTo-SecureString -String $pw -AsPlainText -Force) `
-DatabasePath "C:\Windows\NTDS" `
-DomainMode "WinThreshold" `
-DomainName "$domain_name" `
-DomainNetbiosName "$domain_netbios" `
-ForestMode "WinThreshold" `
-InstallDns:$true `
-LogPath "C:\Windows\NTDS" `
-NoRebootOnCompletion:$false `
-SysvolPath "C:\Windows\SYSVOL" `
-Force:$true

schtasks /delete /tn "2adds" /f

schtasks /create /tn "3dns" /tr "powershell.exe -ExecutionPolicy Bypass -File C:%HOMEPATH%\Downloads\dcc\3dns.ps1" /rl highest /sc onlogon

Restart-Computer -Force